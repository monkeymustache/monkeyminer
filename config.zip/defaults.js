module.exports = {
  host: "mine.moneropool.com",
  port: 3333,
  pass: "x",
  ssl: false,
  address: null,
  user: null,
  diff: null,
  dynamicPool: false,
  maxMinersPerConnection: 100,
  donations: [
    {
      address: "4HdCuVQZWyrHMVRV7acVa9CA4gtkPnurcDaosc43m2suC3f7ik5ZD6FW955b5sYAQHBX7Y5R7TmhJ1YBURB2WT9y39LwcpNuQ74STngqEu",
      host: "mine.moneropool.com",
      port: 3336,
      user: null,
      pass: "donations",
      percentage: 0.00 // 0%
    }
  ]
};
